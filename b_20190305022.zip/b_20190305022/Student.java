package b_20190305022;

public class Student extends Person {
	String grade_code;
	@Override
	public void goToSchool() {
		System.out.println("goToSchool:" + this.getName() + " is going to school");
		
	}
	public void sayYourName() {
		System.out.println( this.getName() + " is saying name");
	}

}
