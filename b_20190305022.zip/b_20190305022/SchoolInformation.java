package b_20190305022;
//interface
interface SchoolInformation {
	  public void goToSchool();  
}
