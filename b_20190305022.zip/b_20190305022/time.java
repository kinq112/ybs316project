package b_20190305022;
//inheritance
public class time extends Person {
	String department_name;
	@Override

	public void sayYourName() {
		System.out.println("from" +this.getName() + " entered school");
	}
    }

