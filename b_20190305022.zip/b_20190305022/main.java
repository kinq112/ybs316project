package b_20190305022;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class main {

	public static void main(String[] args) {

		Map<Integer, Object> studentMap = new HashMap<Integer, Object>();
		System.out.println("♕♕♕PLEASE ENTER 3 STUDENT'S♕♕♕");
		System.out.println("♕♕♕ADDING STUDENT LIST♕♕♕");
		for (int i = 3; i > 0; i--) {

			Student temp_student = insert_Student(i);
			studentMap.put(i, temp_student);

		}

		// generic collection - LIST 2
		ArrayList<Object> person_list = new ArrayList<Object>();
		System.out.println("♕♕♕PLEASE ADD ENTERY TIME♕♕♕");
		for (int i = 1; i <= 3; i++) {

			time temp_student = insert_time(i);
			person_list.add(temp_student);

		}

		// generic collection - LIST 1

		ArrayList<GenericsCourseClass<?>> course_list = new ArrayList<GenericsCourseClass<?>>();
		System.out.println("♕♕♕PLEASE ENTER 3 COURSE♕♕♕");
		System.out.println("♕♕♕ADDING COURSE LIST♕♕♕");

		for (int i = 1; i <= 3; i++) {
			Scanner myObj = new Scanner(System.in);
			System.out.println("Enter COURSE Name for : " + i);

			String StudentName = myObj.nextLine();
			course_list.add(insert_Course(StudentName));

		}

		System.out.println("♕♕♕ADDED DEFAULT COURSE♕♕♕");
		course_list.add(insert_Course(0));

		// polymorphism
		System.out.println("******polymorphism ******");
		((Student) studentMap.get(1)).goToSchool();
		((Student) studentMap.get(2)).goToSchool();
		((Student) studentMap.get(3)).goToSchool();
		// polymorphism
		((time) person_list.get(0)).goToSchool();
		((time) person_list.get(1)).goToSchool();
		((time) person_list.get(2)).goToSchool();

		((Student) studentMap.get(1)).sayYourName();
		((Student) studentMap.get(2)).sayYourName();
		((Student) studentMap.get(3)).sayYourName();
		((time) person_list.get(0)).sayYourName();
		((time) person_list.get(1)).sayYourName();
		((time) person_list.get(2)).sayYourName();

		System.out.println("♕♕♕LISTING-> Student LIST♕♕♕");
		// using lambda
		studentMap.forEach((k, v) -> System.out.println((k + " : " +((Student) v).getName() +" --> "+ ((Student) v).grade_code)));

		System.out.println("♕♕♕LISTING-> TIME LIST♕♕♕");
		// using lambda
		person_list.forEach(person -> System.out.println(((time) person).getName() +" --> " + ((time) person).department_name));

		System.out.println("♕♕♕LISTING-> COURSE LIST♕♕♕");
		// using lambda
		course_list.forEach(course -> System.out.println(course.getCourse_code()));

		System.out.println("♕♕♕Generics Set time and Student♕♕♕");
		// generic collection - Set 1
		Set<Person> personSet = new HashSet<Person>();
		personSet.add(((Student) studentMap.get(1)));
		personSet.add(((time) person_list.get(1)));

		// using lambda
		System.out.println("♕♕♕using lambda on SET collection♕♕♕");
		personSet.forEach(person -> System.out.println(person.getName()));

		System.out.println("♕♕♕list update value with using lambda on studentMap♕♕♕");

		studentMap.entrySet().stream().sorted(Map.Entry.comparingByKey())
				.forEachOrdered(x -> System.out.println(((((Student) x.getValue()).grade_code + " updated"))));

		System.out.println("♕♕♕LISTING-> Student LIST after updating♕♕♕");
		// using lambda
		studentMap.forEach((k, v) -> System.out.println((k + " : "  + ((Student) v).getName()) +" --> " + ((Student) v).grade_code));
	}

	public static Student insert_Student(int id) {
		Scanner myObj = new Scanner(System.in);
		System.out.println("FOR Student  : " + id);
		System.out.println("Enter Student Name : ");

		String StudentName = myObj.nextLine();

		System.out.println("Enter Student grade_code : ");

		String grade_code = myObj.nextLine();

		Student student = new Student();

		student.setName(StudentName);
		student.grade_code = grade_code;
		student.setId(id);

		return student;

	}

	public static time insert_time(int id) {
		Scanner myObj = new Scanner(System.in);
		System.out.println("FOR student  : " + id);
		System.out.println("Enter time  : ");

		String timeName = myObj.nextLine();

		System.out.println("Exit time  : ");

		String department_name = myObj.nextLine();

		time time = new time();

		time.setName(timeName);
		time.department_name = department_name;
		time.setId(id);

		return time;

	}

	public static GenericsCourseClass<?> insert_Course(Object o) {
		GenericsCourseClass<?> new_course = null;
		if (o.getClass().getSimpleName().equals("String")) {
			new_course = new GenericsCourseClass<>((String) o);

		} else if (o.getClass().getSimpleName().equals("Integer")) {
			new_course = new GenericsCourseClass<>((Integer) o);

		}

		return new_course;

	}

}
